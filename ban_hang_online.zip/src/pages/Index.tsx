import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Plus, Minus, ShoppingCart, QrCode } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  description: string;
}

interface CartItem {
  product: Product;
  quantity: number;
}

const products: Product[] = [
  {
    id: 1,
    name: 'Áo thun nam',
    price: 150000,
    image: '/placeholder.svg',
    description: 'Áo thun cotton 100% chất lượng cao'
  },
  {
    id: 2,
    name: 'Quần jean nữ',
    price: 350000,
    image: '/placeholder.svg',
    description: 'Quần jean skinny fit thời trang'
  },
  {
    id: 3,
    name: 'Giày sneaker',
    price: 450000,
    image: '/placeholder.svg',
    description: 'Giày thể thao nam nữ phong cách'
  },
  {
    id: 4,
    name: 'Túi xách nữ',
    price: 280000,
    image: '/placeholder.svg',
    description: 'Túi xách da PU cao cấp'
  },
  {
    id: 5,
    name: 'Đồng hồ nam',
    price: 650000,
    image: '/placeholder.svg',
    description: 'Đồng hồ thời trang chống nước'
  },
  {
    id: 6,
    name: 'Mũ lưỡi trai',
    price: 120000,
    image: '/placeholder.svg',
    description: 'Mũ baseball cap thời trang'
  }
];

const Index = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCheckout, setShowCheckout] = useState(false);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existingItem = prev.find(item => item.product.id === product.id);
      if (existingItem) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const updateQuantity = (productId: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      setCart(prev => prev.filter(item => item.product.id !== productId));
    } else {
      setCart(prev =>
        prev.map(item =>
          item.product.id === productId
            ? { ...item, quantity: newQuantity }
            : item
        )
      );
    }
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  };

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(price);
  };

  const bankInfo = {
    bankName: 'Vietcombank',
    accountNumber: '1234567890',
    accountName: 'NGUYEN VAN A',
    transferContent: `DH${Date.now().toString().slice(-6)}`
  };

  const generateQRContent = () => {
    const amount = getTotalPrice();
    return `https://img.vietqr.io/image/970436-${bankInfo.accountNumber}-compact2.jpg?amount=${amount}&addInfo=${bankInfo.transferContent}&accountName=${encodeURIComponent(bankInfo.accountName)}`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <h1 className="text-2xl font-bold text-gray-900">Cửa Hàng Online</h1>
            <Dialog open={showCheckout} onOpenChange={setShowCheckout}>
              <DialogTrigger asChild>
                <Button variant="outline" className="relative">
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Giỏ hàng
                  {getTotalItems() > 0 && (
                    <Badge className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0 flex items-center justify-center">
                      {getTotalItems()}
                    </Badge>
                  )}
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Giỏ hàng của bạn</DialogTitle>
                </DialogHeader>
                
                {cart.length === 0 ? (
                  <p className="text-center text-gray-500 py-8">Giỏ hàng trống</p>
                ) : (
                  <div className="space-y-4">
                    {/* Cart Items */}
                    <div className="space-y-3">
                      {cart.map((item) => (
                        <div key={item.product.id} className="flex items-center space-x-4 p-3 border rounded-lg">
                          <img
                            src={item.product.image}
                            alt={item.product.name}
                            className="w-16 h-16 object-cover rounded"
                          />
                          <div className="flex-1">
                            <h4 className="font-medium">{item.product.name}</h4>
                            <p className="text-sm text-gray-600">{formatPrice(item.product.price)}</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                            <span className="w-8 text-center">{item.quantity}</span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                          <div className="text-right">
                            <p className="font-medium">{formatPrice(item.product.price * item.quantity)}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    <Separator />

                    {/* Total */}
                    <div className="flex justify-between items-center text-lg font-bold">
                      <span>Tổng cộng:</span>
                      <span className="text-red-600">{formatPrice(getTotalPrice())}</span>
                    </div>

                    <Separator />

                    {/* Payment Info */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold flex items-center">
                        <QrCode className="h-5 w-5 mr-2" />
                        Thông tin thanh toán
                      </h3>
                      
                      {/* QR Code */}
                      <div className="text-center">
                        <img
                          src={generateQRContent()}
                          alt="QR Code thanh toán"
                          className="mx-auto w-48 h-48 border rounded-lg"
                        />
                        <p className="text-sm text-gray-600 mt-2">Quét mã QR để thanh toán</p>
                      </div>

                      {/* Bank Info */}
                      <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                        <h4 className="font-medium">Thông tin chuyển khoản:</h4>
                        <div className="space-y-1 text-sm">
                          <p><span className="font-medium">Ngân hàng:</span> {bankInfo.bankName}</p>
                          <p><span className="font-medium">Số tài khoản:</span> {bankInfo.accountNumber}</p>
                          <p><span className="font-medium">Tên tài khoản:</span> {bankInfo.accountName}</p>
                          <p><span className="font-medium">Số tiền:</span> <span className="text-red-600 font-bold">{formatPrice(getTotalPrice())}</span></p>
                          <p><span className="font-medium">Nội dung:</span> {bankInfo.transferContent}</p>
                        </div>
                      </div>

                      <div className="bg-blue-50 p-3 rounded-lg">
                        <p className="text-sm text-blue-800">
                          <strong>Lưu ý:</strong> Vui lòng chuyển khoản đúng số tiền và nội dung để đơn hàng được xử lý nhanh chóng.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Sản phẩm nổi bật</h2>
          <p className="text-gray-600">Khám phá các sản phẩm chất lượng cao với giá tốt nhất</p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-square overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardHeader>
                <CardTitle className="text-lg">{product.name}</CardTitle>
                <p className="text-sm text-gray-600">{product.description}</p>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-red-600">
                    {formatPrice(product.price)}
                  </span>
                  <Button onClick={() => addToCart(product)} className="ml-4">
                    <Plus className="h-4 w-4 mr-2" />
                    Thêm vào giỏ
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600">
            <p>&copy; 2024 Cửa Hàng Online. Tất cả quyền được bảo lưu.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
